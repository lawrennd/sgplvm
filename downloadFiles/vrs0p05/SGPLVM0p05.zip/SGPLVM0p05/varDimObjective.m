function f = varDimObjective(params,model,X,dim)

% VARDIMOBJECTIVE Objective of output variance over subspace
%
%	Description:
%
%	F = VARDIMOBJECTIVE(PARAMS, MODEL, X, DIM) Computes outputvariance
%	associated with latent location
%	 Returns:
%	  F - objective
%	 Arguments:
%	  PARAMS - latent subspace
%	  MODEL - fgplvm model generating observation
%	  X - full latent location
%	  DIM - latent dimensions to alter
%	
%
%	See also
%	VARDIMGRADIENT


%	Copyright (c) Carl Henrik Ek, 2008 Neil D. Lawrence
% 	varDimObjective.m SVN version 79
% 	last update 2008-09-12T09:32:03.000000Z

X(dim) = params;

[void f] = gpPosteriorMeanVar(model,X);
f = f(:,1);

return;