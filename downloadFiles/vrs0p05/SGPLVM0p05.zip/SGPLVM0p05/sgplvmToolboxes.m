
% SGPLVMTOOLBOXES Load in the relevant toolboxes for sgplvm.
%
%	Description:
%	% 	sgplvmToolboxes.m SVN version 112
% 	last update 2008-10-12T18:53:16.000000Z
importLatest('netlab');
importLatest('prior');
importLatest('optimi');
importLatest('datasets');
importLatest('ndlutil');
importLatest('mocap');
importLatest('mltools');
importLatest('kern');
importLatest('gp');
importLatest('fgplvm');
importLatest('ncca');