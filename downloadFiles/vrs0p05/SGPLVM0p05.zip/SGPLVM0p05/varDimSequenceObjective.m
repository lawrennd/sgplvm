function f = varDimSequenceObjective(params,model,X,dim,varargin)

% VARDIMSEQUENCEOBJECTIVE Objective of output variance over
%
%	Description:
%	subspace sequence
%
%	F = VARDIMSEQUENCEOBJECTIVE(PARAMS, MODEL, X, DIM) Computes
%	outputvariance associated with latent sequence
%	 Returns:
%	  F - objective
%	 Arguments:
%	  PARAMS - latent subspace sequence
%	  MODEL - fgplvm model generating observation
%	  X - full latent sequence
%	  DIM - latent dimensions to alter
%	
%
%	See also
%	VARDIMSEQUENCEGRADIENT


%	Copyright (c) Carl Henrik Ek, 2008 Neil D. Lawrence
% 	varDimSequenceObjective.m SVN version 81
% 	last update 2008-09-12T09:32:03.000000Z

X(:,dim) = reshape(params,size(X,1),length(dim));
Y = gpPosteriorMeanVar(model,X);
X = X(:)';

f = fgplvmSequenceObjective(X,model,Y,varargin{:});

return;
