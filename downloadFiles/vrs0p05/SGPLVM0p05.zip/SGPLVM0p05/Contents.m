% SGPLVM toolbox
% Version 0.05		13-Oct-2008
% Copyright (c) 2008, 

% 
, 

% SGPLVMOPTIONS Return default options for FGPLVM model.
% SGPLVMINITIALISELATENTSEQUENCE Initialise latent location given observation(s)
% SGPLVMOPTIMISEDIMVAR Optimise subspace of latent location
% SGPLVMDYNAMICINDICESOPTIONS 
% SGPLVMADDINVERSEMAPPING
% SGPLVMDISPLAYPRIVATE Display orthogonal subspace of sgplvm model
% SGPLVMVISUALISE Display sgplvm model
% SGPLVMOUT 
% SGPLVMADDLATENTMAPPING
% VARDIMSEQUENCEOBJECTIVE Objective of output variance over
% SGPLVMPOINTOUT Output latent location for observation
% SGPLVMADDBACKMAPPING
% SGPLVMLOGLIKEGRADIENTS Compute the gradients for the SGPLVM.
% SGPLVMEXTRACTPARAM Extract a parameter vector from a GP-LVM model.
% SGPLVMGRADIENT sGP-LVM gradient wrapper.
% VARDIMSEQUENCEGRADIENT Output variance gradient for latent sequence
% SGPLVMSEQUENCEOUT Output latent location for observation
% SGPLVMEXPANDPARAM Expand a parameter vector into a sGP-LVM model.
% SGPLVMCREATE Creates a shared FGPLVM model from a set of FGPLVM models
% VARDIMGRADIENT Output variance gradient
% SGPLVMSETLATENTDIMENSION Specify latent dimension type
% SGPLVMOBJECTIVE Wrapper function for GP-LVM objective.
% SGPLVMINITIALISELATENTPOINT Initialise latent location given observation(s)
% SGPLVMMODELOPTIONS Return default options for SGPLVM model.
% SGPLVMDISPLAYLATENT
% SGPLVMADDDYNAMICS Add dynamic model over latent space
% VARDIMOBJECTIVE Objective of output variance over subspace
% SGPLVMOPTIMISEDIMVARSEQUENCE Optimise subspace of latent sequence
% SGPLVMLOGLIKELIHOOD Log-likelihood for a sGP-LVM.
% SGPLVMOBJECTIVEGRADIENT Wrapper function for SGPLVM objective and gradient.
% SGPLVMOPTIMISE Optimise the SGPLVM.
% SGPLVMTOOLBOXES Load in the relevant toolboxes for sgplvm.
% NCCA2SGPLVM Convert a NCCA model into a SGPLVM model
% DEMSGPLVM Demonstrate teh SGPLVM.
