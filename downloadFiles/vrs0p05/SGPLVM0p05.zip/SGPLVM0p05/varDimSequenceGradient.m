function g = varDimSequenceGradient(params,model,X,dim,varargin)

% VARDIMSEQUENCEGRADIENT Output variance gradient for latent sequence
%
%	Description:
%
%	G = VARDIMSEQUENCEGRADIENT(PARAMS, MODEL, X, DIM) Compute latent
%	gradients for output space variance of a sequence
%	 Returns:
%	  G - gradients
%	 Arguments:
%	  PARAMS - latent locations for optimised dimensions
%	  MODEL - fgplvm model generating observation space
%	  X - complete latent location
%	  DIM - optimised dimensions
%	
%
%	See also
%	VARDIMSEQUENCEOBJECTIVE


%	Copyright (c) Carl Henrik Ek, 2008 Neil D. Lawrence
% 	varDimSequenceGradient.m SVN version 80
% 	last update 2008-09-12T09:32:03.000000Z


X(:,dim) = reshape(params,size(X,1),length(dim));
Y = gpPosteriorMeanVar(model,X);
X = X(:)';

g = fgplvmSequenceGradient(X,model,Y,varargin{:});
g = reshape(g,size(Y,1),model.q);
g = g(:,dim);
g = g(:)';

return;