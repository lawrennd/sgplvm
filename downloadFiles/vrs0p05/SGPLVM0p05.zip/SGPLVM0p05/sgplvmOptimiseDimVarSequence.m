function X = sgplvmOptimiseDimVarSequence(model_obs,model_dyn,X,dim,balancing,display,iters,gradcheck,optimiser)

% SGPLVMOPTIMISEDIMVARSEQUENCE Optimise subspace of latent sequence
%
%	Description:
%
%	X = SGPLVMOPTIMISEDIMVARSEQUENCE(MODEL_OBS, MODEL_DYN, X, DIM,
%	BALANCING, DISPLAY, ITERS, GRADCHECK, OPTIMISER) Takes a fgplvm
%	model and finds the latent location minimizing the variance on the
%	output space
%	 Returns:
%	  X - optimised latent location
%	 Arguments:
%	  MODEL_OBS - fgplvm model generating observations
%	  MODEL_DYN - dynamical model
%	  X - latent initialisation
%	  DIM - dimensions to optimise
%	  BALANCING - balancing between generative and sequential objective
%	   terms
%	  DISPLAY - display optimisation iterations
%	  ITERS - maximum number of iterations
%	  GRADCHECK - check gradients
%	  OPTIMISER - optimiser (default = 'scg')
%	
%
%	See also
%	SGPLVMOPTIMISEDIMVAR


%	Copyright (c) 2008 Neil D. Lawrence and Carl Henrik Ek
% 	sgplvmOptimiseDimVarSequence.m SVN version 107
% 	last update 2008-10-11T20:25:39.000000Z

if(nargin<9)
  optimiser = 'scg';
  if(nargin<8)
    gradcheck = false;
    if(nargin<7)
      iters = 100;
      if(nargin<6)
	display = 0;
	if(nargin<5)
	  balancing = 1;
	  if(nargin<4)
	    error('Too Few Arguments');
	  end
	end
      end
    end
  end
end

% check arguments
if(~isempty(setdiff(dim,model_dyn.indexOut)))
  fprintf('sgplvmOptimiseDimVarSequence:\tDynamic model does not cover all requested dimensions\n');
end

model = model_obs;
model.dynamics = model_dyn;

% set optimisation settings
options = optOptions;
options(14) = iters;
options(9) = gradcheck;
options(1) = display;

optFunc = str2func(optimiser);

% optimise
params = X(:,dim);
params = params(:)';
params = optFunc('varDimSequenceObjective',params,options,'varDimSequenceGradient',model,X,dim,balancing);

X(:,dim) = reshape(params,size(X,1),length(dim));


return;
