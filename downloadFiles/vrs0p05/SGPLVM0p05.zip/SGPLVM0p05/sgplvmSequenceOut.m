function [X X_init]= sgplvmSequenceOut(model,Y,index_in,index_out,type,dim,index_dyn,N,iters,display,balancing,gradcheck,optimiser,verbose)

% SGPLVMSEQUENCEOUT Output latent location for observation
%
%	Description:
%
%	X = SGPLVMSEQUENCEOUT(MODEL, Y, INDEX_IN, INDEX_OUT, TYPE, DIM,
%	INDEX_DYN, N, ITERS, DISPLAY, BALANCING, GRADCHECK, OPTIMISER,
%	VERBOSE) Takes a sgplvm model and finds latent location
%	corresponding to a sequence of observations
%	 Returns:
%	  X - latent location
%	 Arguments:
%	  MODEL - sgplvm model
%	  Y - observation sequence
%	  INDEX_IN - model component index of observation generating model
%	  INDEX_OUT - model component index of output space
%	  TYPE - type of initialisation
%	  DIM - dimensions to alter
%	  INDEX_DYN - model component index to dynamic model
%	  N - type argument
%	  ITERS - maximum number of iterations in optimisation
%	  DISPLAY - display optimisation iterations
%	  BALANCING - balancing between generative and sequential objective
%	   terms
%	  GRADCHECK - check gradients
%	  OPTIMISER - optimiser (default = 'scg')
%	  VERBOSE - 
%	
%
%	See also
%	% SEEALSO SGPLVMSEQUENCEOUT


%	Copyright (c) Carl Henrik Ek, 2008 Neil D. Lawrence
% 	sgplvmSequenceOut.m SVN version 75
% 	last update 2008-09-12T09:32:03.000000Z

%1. Initialise sequence
X_init = sgplvmInitialiseLatentSequence(model,Y,index_in,index_out,index_dyn,type,N,verbose);

%2. Optimise sequence
if(model.dynamic)
  X = sgplvmOptimiseDimVarSequence(model.comp{index_in},model.dynamics.comp{index_dyn},X_init,dim,balancing,display,iters,gradcheck,optimiser);
else
  X = X_init;
end
  
return;

