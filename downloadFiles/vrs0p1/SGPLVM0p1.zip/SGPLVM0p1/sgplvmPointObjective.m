function f = sgplvmPointObjective(x,model,Y,comps)

% SGPLVMPOINTOBJECTIVE Gradient of latent location given observed points
%
%	Description:
%
%	MODEL = SGPLVMPOINTOBJECTIVE(X, MODEL, Y, COMPS) Takes a sgplvm
%	model structure, observed point and latent location and returns
%	objective
%	 Returns:
%	  MODEL - the optimised model
%	 Arguments:
%	  X - latent initialisation
%	  MODEL - sgplvm model
%	  Y - observed data (if more than one observation space as cell
%	   array)
%	  COMPS - generative models associated with observed data
%	
%
%	See also
%	SGPLVMPOINTGRADIENT, 


%	Copyright (c) Carl Henrik Ek, 2007 Neil D. Lawrence
% 	sgplvmPointObjective.m SVN version 865
% 	last update 2010-06-10T10:47:17.000000Z


if(length(comps)==1&&~iscell(Y))
  f = fgplvmPointObjective(x,model.comp{comps(1)},Y);
else
  f = 0;
  for(i = 1:1:length(comps))
    f = f + fgplvmPointObjective(x,model.comp{comps(i)},Y{i});
  end
end

return