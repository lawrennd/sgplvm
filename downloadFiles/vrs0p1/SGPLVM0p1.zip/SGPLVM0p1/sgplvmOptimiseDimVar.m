function X = sgplvmOptimiseDimVar(model,X,dim,display,iters,gradcheck,optimiser)

% SGPLVMOPTIMISEDIMVAR Optimise subspace of latent location
%
%	Description:
%
%	X = SGPLVMOPTIMISEDIMVAR(MODEL, X, DIM, DISPLAY, ITERS, GRADCHECK,
%	OPTIMISER) Takes a fgplvm model and finds the latent location
%	minimizing the variance on the output space
%	 Returns:
%	  X - optimised latent location
%	 Arguments:
%	  MODEL - fgplvm model
%	  X - latent initialisation
%	  DIM - dimensions to optimise
%	  DISPLAY - display optimisation iterations
%	  ITERS - maximum number of iterations
%	  GRADCHECK - check gradients
%	  OPTIMISER - optimiser (default = 'scg')
%	
%
%	See also
%	SGPLVMOPTIMISEDIMVARSEQUENCE


%	Copyright (c) Carl Henrik Ek, 2008 Neil D. Lawrence
% 	sgplvmOptimiseDimVar.m SVN version 401
% 	last update 2009-06-23T09:09:51.000000Z

if(nargin<7)
  optimiser = 'scg';
  if(nargin<6)
    gradcheck = false;
    if(nargin<5)
      iters = 100;
      if(nargin<4)
	display = 0;
	if(nargin<3)
	  error('Too Few Arguments');
	end
      end
    end
  end
end

% set optimisation settings
options = optOptions;
options(14) = iters;
options(9) = gradcheck;
options(1) = display;

optFunc = str2func(optimiser);


for(i = 1:1:size(X,1))
  X(i,dim) = optFunc('varDimObjective',X(i,dim),options,'varDimGradient',model,X(i,:),dim);
end

return;
