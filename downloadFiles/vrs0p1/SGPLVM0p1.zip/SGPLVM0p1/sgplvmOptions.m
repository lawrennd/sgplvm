function options = sgplvmOptions

% SGPLVMOPTIONS Return default options for FGPLVM model.
%
%	Description:
%
%	OPTIONS = SGPLVMOPTIONS(NULL) Returns the defualt options for a
%	sgplvm model
%	 Returns:
%	  OPTIONS - structure containing defualt options
%	 Arguments:
%	  NULL - NULL
%	
%
%	See also
%	SGPLVMCREATE, GPOPTIONS


%	Copyright (c) Carl Henrik Ek, 2007 Neil D. Lawrence
% 	sgplvmOptions.m SVN version 401
% 	last update 2009-06-23T09:09:51.000000Z

options.optimiser = 'scg';
options.name = 'sgplvm_';
options.save_intermediate = inf;
options.fols = [];