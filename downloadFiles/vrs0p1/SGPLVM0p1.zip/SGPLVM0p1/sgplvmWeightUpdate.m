function model = sgplvmWeightUpdate(model,t,verbose)

% SGPLVMWEIGHTUPDATE Update iteration dependent objective weights
%
%	Description:
%
%	MODEL = SGPLVMWEIGHTUPDATE(MODEL, T, VERBOSE) Updated objective
%	function weights of the fols sgplvm model
%	 Returns:
%	  MODEL - sgplvm model with updated weights
%	 Arguments:
%	  MODEL - fols sgplvm model
%	  T - current iteration number
%	  VERBOSE - 
%	
%
%	See also
%	SGPLVMLOGLIKELIHOOD, SGPLVMPLOTDECAYFUNCTION


%	Copyright (c) Carl Henrik Ek, Mathieu Salzmann, 2009 Neil D. Lawrence
% 	sgplvmWeightUpdate.m SVN version 401
% 	last update 2009-06-23T09:09:51.000000Z

if(nargin<3)
  verbose = true;
end

if(isfield(model.fols,'rank'))
  % alpha
  w = computeSigmoidWeight(t,model.fols.rank.alpha.decay.rate,model.fols.rank.alpha.decay.shift);
  model.fols.rank.alpha.weight = model.fols.rank.alpha.weight_init*w;
  if(model.fols.rank.alpha.weight<model.fols.rank.alpha.decay.truncate)
    model.fols.rank.alpha.weight = 0;
  end
  % gamma
  w = computeSigmoidWeight(t,model.fols.rank.gamma.decay.rate,model.fols.rank.gamma.decay.shift);                   
  model.fols.rank.gamma.weight = model.fols.rank.gamma.weight_init*w; 
  if(model.fols.rank.gamma.weight<model.fols.rank.gamma.decay.truncate)
    model.fols.rank.gamma.weight = 0;
  end
  if(verbose)
    fprintf('Alpha:\t%f\n',model.fols.rank.alpha.weight);
    fprintf('Gamma:\t%f\n',model.fols.rank.gamma.weight);
  end
end
if(isfield(model.fols,'ortho'))
  w = computeSigmoidWeight(t,model.fols.ortho.decay.rate,model.fols.ortho.decay.shift);
  model.fols.ortho.weight = model.fols.ortho.weight_init*w;
  if(model.fols.ortho.weight<model.fols.ortho.decay.truncate)
    model.fols.ortho.weight = 0;
  end
  if(verbose)
    fprintf('Ortho:\t%f\n',model.fols.ortho.weight);
  end
end

return
