function x = sgplvmOptimisePoint(model,x,Y,display,iters,comps,gradcheck)

% SGPLVMOPTIMISEPOINT Optimise the latent location.
%
%	Description:
%
%	MODEL = SGPLVMOPTIMISEPOINT(MODEL, X, Y, DISPLAY, ITERS, COMPS,
%	GRADCHECK) Takes a sgplvm model structure, observed point and latent
%	initialisation and optimises latent location
%	 Returns:
%	  MODEL - x latent location
%	 Arguments:
%	  MODEL - sgplvm model
%	  X - latent initialisation
%	  Y - observed data
%	  DISPLAY - flag dictating wheter or not to display optimisation
%	   progress (set to greater than zero) (default = 1)
%	  ITERS - maximum number of iterations (default = 2000)
%	  COMPS - generative models associated with observed data
%	  GRADCHECK - Should analytic gradientes be compared with finite
%	   differences of objective (default = false)
%	
%
%	See also
%	SGPLVMOBJECTIVE, SGPLVMGRADIENT


%	Copyright (c) Carl Henrik Ek, 2007 Neil D. Lawrence
% 	sgplvmOptimisePoint.m SVN version 865
% 	last update 2010-06-10T10:47:17.000000Z


if(nargin<7)
  gradcheck = false;
end

options = optOptions;
if(display)
  options(1) = true;
end
if(gradcheck)
  options(9) = true;
end
options(14) = iters;

if isfield(model, 'optimiser')
  optim = str2func(model.optimiser);
else
  optim = str2func('scg');
end

x = optim('sgplvmPointObjective',x,options,'sgplvmPointGradient',model,Y, ...
          comps);

return;