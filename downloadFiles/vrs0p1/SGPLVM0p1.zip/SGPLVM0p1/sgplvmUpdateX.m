function model = sgplvmUpdateX(model,X);

% SGPLVMUPDATEX Optimise the SGPLVM.
%
%	Description:
%
%	MODEL = SGPLVMUPDATEX(MODEL, X) Takes a sgplvm model structure and
%	optimises with respect to parameters and latent coordinates
%	 Returns:
%	  MODEL - the model with updated latent representation
%	 Arguments:
%	  MODEL - sgplvm model
%	  X - latent representation to update the model with
%	
%
%	See also
%	


%	Copyright (c) Carl Henrik Ek, 2007 Neil D. Lawrence
% 	sgplvmUpdateX.m SVN version 815
% 	last update 2010-05-28T06:01:33.000000Z


model.X = X;
for(i = 1:1:model.numModels)
      model.comp{1}.X = X;
end

return