function [f, g] = sgplvmObjectiveGradient(params, model)

% SGPLVMOBJECTIVEGRADIENT Wrapper function for SGPLVM objective and gradient.
%
%	Description:
%
%	[F, G] = SGPLVMOBJECTIVEGRADIENT(PARAMS, MODEL) : returns the
%	negative log likelihood and the gradients of the negative log
%	likelihood for the given model and parameters
%	 Returns:
%	  F - negative log likelihood of model
%	  G - gradient of negative log likelihood
%	 Arguments:
%	  PARAMS - the parameters of the model for which the objective and
%	   gradients will be evaluated
%	  MODEL - the sgplvm model
%	sgplvmOptimise
%	
%
%	See also
%	MINIMIZE, SGPLVMGRADIENT, SGPLVMLOGLIKELIHOOD, 


%	Copyright (c) Carl Henrik Ek, 2007 Neil D. Lawrence
% 	sgplvmObjectiveGradient.m SVN version 401
% 	last update 2009-06-23T09:09:51.000000Z

% Check how the optimiser has given the parameters
if size(params, 1) > size(params, 2)
  % As a column vector ... transpose everything.
  transpose = true;
  model = sgplvmExpandParam(model, params');
else
  transpose = false;
  model = sgplvmExpandParam(model, params);
end

f = - sgplvmLogLikelihood(model);
if nargout > 1
  g = - sgplvmLogLikeGradients(model);
  if transpose
    g = g';
  end
end
