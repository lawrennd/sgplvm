function X = sgplvmPointOut(model,index_in,index_out,Y,type,N,Nopt,verbose,varargin)

% SGPLVMPOINTOUT Output latent location for observation
%
%	Description:
%
%	X = SGPLVMPOINTOUT(MODEL, INDEX_IN, INDEX_OUT, Y, TYPE, N, NOPT,
%	VERBOSE) Takes a sgplvm model and finds latent location
%	 Returns:
%	  X - latent location
%	 Arguments:
%	  MODEL - sgplvm model
%	  INDEX_IN - model component index of observation generating model
%	  INDEX_OUT - model component index of output space
%	  Y - observation
%	  TYPE - type of initialisation
%	  N - type argument
%	  NOPT - maximum number of iterations in optimisation
%	  VERBOSE - 
%	
%
%	See also
%	% SEEALSO SGPLVMSEQUENCEOUT


%	Copyright (c) Carl Henrik Ek, 2008 Neil D. Lawrence
% 	sgplvmPointOut.m SVN version 74
% 	last update 2008-09-12T09:32:03.000000Z

% Set default arguments
if(nargin<8)
  verbose = false;
  if(nargin<7)
    Nopt = 100;
    if(nargin<6)
      N = 5;
      if(nargin<5)
	type = 'NN';
	if(nargin<4)
	  error('Too Few Arguments');
	end
      end
    end
  end
end

%1. Initialise Latent Coordinate
X_init = sgplvmInitialiseLatentPoint(model,Y,index_in,index_out,type,N,verbose);
if(Nopt==0)
  if(verbose)
    fprintf('sgplvmPointOut:\t Returning initialisation\n');
  end
  X = X_init;
else
  %2. Optimise Point
  for(i = 1:1:N)
    X(i,:) = fgplvmOptimisePoint(model.comp{index_in},X_init(i,:),Y,verbose,Nopt);
  end
end

return;

