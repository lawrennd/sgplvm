function ind = sgplvmDynamicIndicesOptions(model,N,seq,type);

% SGPLVMDYNAMICINDICESOPTIONS
%
%	Description:
%
%	IND = SGPLVMDYNAMICINDICESOPTIONS(MODEL, N, SEQ, TYPE) Returns a set
%	of indices to be used as inducing indices for a GP-Dynamic model
%	 Returns:
%	  IND - index vector
%	 Arguments:
%	  MODEL - sgplvm model
%	  N - number of inducing points
%	  SEQ - sequence
%	  TYPE - type of spacing of indices (default = linspace)
%	
%
%	See also
%	SGPLVMCREATE


%	Copyright (c) Carl Henrik Ek, 2007 Neil D. Lawrence
% 	sgplvmDynamicIndicesOptions.m SVN version 57
% 	last update 2008-09-12T09:32:03.000000Z

if(nargin<4)
  type = 'linspace';
  if(nargin<3)
    seq = [];
    if(nargin<2)
      N = model.k;
      if(nargin<1)
	error('To Few Arguments');
      end
    end
  end
end

validIndices = 1:1:(model.N-length(seq));
switch type
 case 'linspace'
  ind = round(linspace(1,length(validIndices),N));
 case 'rand'
  ind = randperm(length(validIndices));
  ind = validIndices(ind);
 otherwise
  error('Unkown Type');
end

return
