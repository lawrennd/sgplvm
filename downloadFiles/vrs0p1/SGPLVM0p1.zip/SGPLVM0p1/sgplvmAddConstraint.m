function model = sgplvmAddConstraint(model,param1);

% SGPLVMADDCONSTRAINT Add latent constraints to SGPLVM model
%
%	Description:
%
%	MODEL = SGPLVMADDCONSTRAINT(MODEL, OPTIONS) Adds constraint
%	structure to FGPLVM model
%	 Returns:
%	  MODEL - the SGP-LVM model.
%	 Arguments:
%	  MODEL - fgplvm model
%	  OPTIONS - options strucure as returnded from constraintOptions
%	
%
%	See also
%	CONSTRAINTOPTIONS


%	Copyright (c) 2009 Carl Henrik Ek
% 	sgplvmAddConstraint.m SVN version 867
% 	last update 2010-06-10T10:51:02.000000Z


if(isfield(model,'type')&&strcmp(model.type,'fgplvm'))
  m = param1;
  type = 'model';
else
  options = param1;
  type = 'options';
end
  

switch type
 case 'options'
  % create new constraints
  fhandle = str2func(['constraintCreate',options.type]);
  options.N = model.N;
  options.q = model.q;
  if(isfield(model,'constraints')&&~isempty(model.constraints))
    model.constraints.comp{model.constraints.numConstraints+1} = fhandle(options);
  else
    model.constraints.comp{1} = fhandle(options);
    model.constraints.numConstraints = 0;
    model.constraints.id = [];
  end  
  model.constraints.numConstraints = model.constraints.numConstraints + 1;
  model.constraints.id = [model.constraints.id; false*ones(1,model.q)];
  model.constraints.id(end,options.dim) = true;
  model.constraint_id = model.constraints.id;
 case 'model'
  % transfer constraints
  if(isfield(model,'constraints')&&~isempty(model.constraints))
    for(i = 1:1:m.constraints.numConstraints)
      model.constraints.comp{model.constraints.numConstraints+1} = m.constraints.comp{i};
      model.constraint_id = [model.constraint_id m.constraints.id]; 
      model.constraints.numConstraints = model.constraints.numConstraints + 1;
    end
  else
    for(i = 1:1:m.constraints.numConstraints)
      model.constraints.comp{i} = m.constraints.comp{i};
      model.constraint_id = false*one(1,model.q);
      model.constraint_id(i.m.constraints.dim) = true;
    end
    model.constraints.numConstraints = m.constraints.numConstraints;
  end
end

if(~isempty(model.constraints))
  model.constraint = true;
else
  model.constraint = false;
end

% update constraints
for(i = 1:1:model.constraints.numConstraints)
  model.constraints.comp{i} = constraintExpandParam(model.constraints.comp{i},model.X);
end

return
