function handle = imagegreyVisualise(pos,fid,imageSize)

% IMAGEGREYVISUALISE Callback function to visualise 2D image
%
%	Description:
%	handle = imagegreyVisualise(pos,fid,imageSize)
%% 	imagegreyVisualise.m SVN version 815
% 	last update 2010-05-28T06:01:33.000000Z

if(nargin<2)
  fid = 2;
end

figure(fid);
colormap gray;

imageData = reshape(pos, imageSize(1), imageSize(2));
imageData = imageData./max(max(imageData));
handle = imagesc(imageData);

return;