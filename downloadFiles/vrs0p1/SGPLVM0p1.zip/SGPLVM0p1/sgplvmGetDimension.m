function dim = sgplvmGetDimension(model,type,model_id)

% SGPLVMGETDIMENSION Returns dimensions by type from SGPLVM model
%
%	Description:
%
%	DIM = SGPLVMGETDIMENSION(MODEL, TYPE, MODEL_ID) Returns dimension by
%	type from SGPLVM model
%	 Returns:
%	  DIM - the dimensions as a row vector
%	 Arguments:
%	  MODEL - SGPLVM model
%	  TYPE - type of latent dimensions, (shared,private,generative)
%	  MODEL_ID - index of model into SGPLVM struct for private and
%	   generative dimension
%	
%	
%
%	See also
%	SGPLVMOPTIONS


%	Copyright (c) Carl Henrik Ek, 2007 Neil D. Lawrence


%	With modifications by Carl Henrik Ek 2010
% 	sgplvmGetDimension.m SVN version 760
% 	last update 2010-04-13T14:06:07.000000Z


if(~strcmp(type,'shared')&&nargin<3)
  error('Need to specify model id when requesting private or generative dimensions');
end
if(nargin<3)
  model_id = [];
end


dim = [];
switch type
 case 'shared'
  if(isempty(model_id)||length(model_id)==1)
    % Return dimensions shared by all models
    for(i = 1:1:model.q)
      if(length(find(model.generative_id(:,i)))==model.numModels)
        dim = [dim i];
      end
    end
  else
    % Return dimensions shared by model_id models
    for(i = 1:1:model.q)
      if(length(find(model.generative_id(model_id,i)))==length(model_id))
        dim = [dim i];
      end
    end
  end
 case 'private'
  for(i = 1:1:model.q)
    tmp = find(model.generative_id(:,i));
    if(length(tmp)==1&&tmp==model_id)
      dim = [dim i];
    end
  end
 case {'generative','generating'}
  dim = find(model.generative_id(model_id,:));
end

return;