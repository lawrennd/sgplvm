function g = varDimGradient(params,model,X,dim)

% VARDIMGRADIENT Output variance gradient
%
%	Description:
%
%	G = VARDIMGRADIENT(PARAMS, MODEL, X, DIM) Compute latent gradients
%	for output space variance
%	 Returns:
%	  G - gradients
%	 Arguments:
%	  PARAMS - latent locations for optimised dimensions
%	  MODEL - fgplvm model generating observation space
%	  X - complete latent location
%	  DIM - optimised dimensions
%	
%
%	See also
%	VARDIMOBJECTIVE


%	Copyright (c) Carl Henrik Ek, 2008 Neil D. Lawrence
% 	varDimGradient.m SVN version 401
% 	last update 2009-06-23T09:09:51.000000Z

X(:,dim) = params;

[void g] = gpPosteriorGradMeanVar(model,X);
g = g(dim,1)';

return;