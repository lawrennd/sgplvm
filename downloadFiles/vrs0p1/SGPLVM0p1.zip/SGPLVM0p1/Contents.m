% SGPLVM toolbox
% Version 0.1		11-Jun-2010
% Copyright (c) 2010, 

% 
, 

% SGPLVMADDBACKMAPPING
% SGPLVMEXPANDPARAM Expand a parameter vector into a sGP-LVM model.
% SGPLVMDYNAMICINDICESOPTIONS 
% SGPLVMSETLATENTDIMENSION Specify latent dimension type
% SGPLVMOPTIMISEDIMVAR Optimise subspace of latent location
% SGPLVMVISUALISE Display sgplvm model
% NCCA2SGPLVM Convert a NCCA model into a SGPLVM model
% SGPLVMOPTIMISEPOINT Optimise the latent location.
% SGPLVMFOLSOPTIONS Returns options struct for fols model
% SGPLVMEXTRACTPARAM Extract a parameter vector from a GP-LVM model.
% SGPLVMOBJECTIVE Wrapper function for GP-LVM objective.
% SGPLVMLOGLIKEGRADIENTS Compute the gradients for the SGPLVM.
% SGPLVMPOINTOBJECTIVE Gradient of latent location given observed points
% COMPUTESIGMOIDWEIGHT Compute weight decay function for fols model
% SGPLVMCONSTRAINTSGRADIENT SGPLVM constraints and gradient function for fmincon usage.
% SGPLVMPLOTDECAYFUNCTION Plot fols decay functions
% SGPLVMINITIALISELATENTPOINT Initialise latent location given observation(s)
% SGPLVMPOINTGRADIENT Gradient of latent location given observed points
% SGPLVMLOGLIKELIHOOD Log-likelihood for a SGP-LVM.
% SGPLVMCROPPDIMENSIONDYNAMICSGETVALIDDIMENSION Returns valid
% SGPLVMOBJECTIVEGRADIENT Wrapper function for SGPLVM objective and gradient.
% SGPLVMCROPPDIMENSION Removes latent dimensions representing
% SGPLVMMODELOPTIONS Return default options for SGPLVM model.
% ORTHOLOGLIKEGRADIENTS Compute the FOLS orthogonality constraint gradients for the SGPLVM.
% SGPLVMSEQUENCEOUT Output latent location for observation
% SGPLVMTOOLBOXES Load in the relevant toolboxes for sgplvm.
% SGPLVMOPTIMISEDIMVARSEQUENCE Optimise subspace of latent sequence
% VARDIMSEQUENCEGRADIENT Output variance gradient for latent sequence
% SGPLVMINITIALISELATENTPOINTFROMSHARED Initialise latent location given observation(s)
% SGPLVMADDCONSTRAINT Add latent constraints to SGPLVM model
% SGPLVMINITIALISELATENTSEQUENCE Initialise latent location given observation(s)
% SGPLVMCROPPDIMENSIONCONSTRAINTSGETVALIDDIMENSION Returns valid
% SGPLVMADDLATENTMAPPING
% SGPLVMDISPLAYPRIVATE Display orthogonal subspace of sgplvm model
% VARDIMGRADIENT Output variance gradient
% DEMSGPLVM Demonstrate the SGPLVM.
% SGPLVMOPTIMISE Optimise the SGPLVM.
% SGPLVMOPTIONS Return default options for FGPLVM model.
% IMAGEGREYVISUALISE Callback function to visualise 2D image
% SGPLVMOUT 
% SGPLVMCREATE Creates a shared FGPLVM model from a set of FGPLVM models
% NN_CLASS
% VARDIMSEQUENCEOBJECTIVE Objective of output variance over
% IMAGEGREYMODIFY Callback function to visualise 2D image
% SGPLVMADDDYNAMICS Add dynamic model over latent space
% SGPLVMADDINVERSEMAPPING
% SGPLVMUPDATEX Optimise the SGPLVM.
% SGPLVMPOINTOUT Output latent location for observation
% SGPLVMWEIGHTUPDATE Update iteration dependent objective weights
% SGPLVMDISPLAYLATENT
% SGPLVMCROPPDIMENSIONBACKVALIDDIMENSION Returns valid
% VARDIMOBJECTIVE Objective of output variance over subspace
% SGPLVMGRADIENT sGP-LVM gradient wrapper.
% DEM_SGPLVM_FOLS Runs Demo of FOLS SGPLVM model
% SGPLVMGETDIMENSION Returns dimensions by type from SGPLVM model
% RANKLOGLIKEGRADIENTS Compute the FOLS rank constraint gradients for the SGPLVM.
