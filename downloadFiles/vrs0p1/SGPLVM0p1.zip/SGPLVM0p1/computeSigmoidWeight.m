function w = computeSigmoidWeight(t,rate,shift)

% COMPUTESIGMOIDWEIGHT Compute weight decay function for fols model
%
%	Description:
%
%	W = COMPUTESIGMOIDWEIGHT(T, RATE, SHIFT) Returns current iterations
%	weight
%	 Returns:
%	  W - current weight
%	 Arguments:
%	  T - current iteration
%	  RATE - decay rate
%	  SHIFT - offset of sigmoid
%	
%
%	See also
%	SGPLVMWEIGHTUPDATE, SGPLVMFOLSOPTIONS


%	Copyright (c) Carl Henrik Ek, Mathieu Salzmann, 2009 Neil D. Lawrence
% 	computeSigmoidWeight.m SVN version 401
% 	last update 2009-06-23T09:09:51.000000Z

w = sigmoid((t-shift).*rate);

return