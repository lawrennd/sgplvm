function g = sgplvmGradient(params, model)

% SGPLVMGRADIENT sGP-LVM gradient wrapper.
%
%	Description:
%
%	G = SGPLVMGRADIENT(PARAMS, MODEL) is a wrapper function for the
%	gradient of the negative log likelihood of an sgplvm model with
%	respect to the latent positions and model parameters
%	 Returns:
%	  G - the gradient of the model negative log likelihood
%	 Arguments:
%	  PARAMS - model parameters for which gradient is to be evaluated
%	  MODEL - sgplvm model
%	
%
%	See also
%	SGPLVMLOGLIKEGRADIENTS, SGPLVMEXPANDPARAM


%	Copyright (c) Carl Henrik Ek, 2007 Neil D. Lawrence
% 	sgplvmGradient.m SVN version 60
% 	last update 2008-09-12T09:32:03.000000Z

model = sgplvmExpandParam(model,params);
g = - sgplvmLogLikeGradients(model);

return