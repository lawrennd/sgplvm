function handle = imagegreyModify(handle,imageValues,imageSize)

% IMAGEGREYMODIFY Callback function to visualise 2D image
%
%	Description:
%	handle = imagegreyModify(handle,imageValues,imageSize)
%% 	imagegreyModify.m SVN version 815
% 	last update 2010-05-28T06:01:33.000000Z


set(handle, 'CData', reshape(imageValues, imageSize(1),imageSize(2)));

return